struct record
{
    int record_num;
    int data;
};

char *RECORD_FILE = "path/to/file";
